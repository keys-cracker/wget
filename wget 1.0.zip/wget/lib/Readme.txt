Dependencies: Git

run merge.bat as admin

after instalation commands (optional) e.g: install Packages      #only from WGET github repository!

     install "program" -edit "repository name"        # Program= name of something from github   #-edit select the install from a custom repository      #-repository name=a repository name

e.g: install BurntToast -edit Windos     #is corect the "Windos" 