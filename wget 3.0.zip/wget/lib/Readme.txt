Dependencies: Git

Run merge.bat As admin


install "Package"                  Install the "Package" from https://github.com/keys-cracker/"Package".git
install "Package" -r               Remove "Package" from downlloaded Packages (Not uninstalling it!).
install "Package" -e "username"    Install the "Package" from https://github.com/"username"/"Package".git
install -v                         Displays the wget Version installed on the machine! (Not wget version e.g: V3.39.0 (global))